let numero1 = 5;
let numero2 = 10;
let suma = numero1 + numero2;
console.log(suma);
let numero3 = 7;
let nuevaSuma = suma + numero3;
console.log(nuevaSuma);


