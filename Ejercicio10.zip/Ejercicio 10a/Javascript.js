let nombre = "Sebastian";
let apellido = "Keiner";

let resultado = nombre + " " + apellido;
console.log(resultado);

